import { MatDatepickerInputEvent, MatAccordion } from '@angular/material';
// import { CandidateDetails } from './candidate.model';
import { Component, OnInit, ChangeDetectorRef, ViewChild } from '@angular/core';
import { HireService } from './hire.service';
import { Router } from '@angular/router';
import {
  FormGroup,
  Validators,
  FormBuilder,
  FormControl,
  FormGroupName,
  FormArray
} from '@angular/forms';
@Component({
  selector: 'app-hire',
  templateUrl: './hire.component.html',
  styleUrls: ['./hire.component.scss']
})
export class HireComponent implements OnInit {
  @ViewChild('hireAccordian') hireAccordian: MatAccordion;
  tabToDisplay = 1;
  step = 1;
  isDisabled = true;
  form: FormGroup;
  position_funding_sources = [{ speedtype: '', percentage: '' }];
  position_cur_index: number = this.position_funding_sources.length;
  today = new Date();
  graduate_position_val: string;
  display_graduate_sec = false;
  start_date: any = '';
  end_date: any = '';
  isEndDateDisable = true;
  errorMessage = '';
  multiValue = false;
  fb:FormBuilder;
  items: FormArray;
  hiring_department = [
    { key: '1010000156', name: '1010000156 - Office of the President' },
    { key: '1010000184', name: '1010000184 -  Office of the President-GIE' },
    { key: '1011000156', name: '1010000156 -  Admin Supp Serv-Stu Serv' },
    { key: '1017000156', name: '1017000156 - Boards - Institutional Support' },
    { key: '1018000144', name: '1018000144 - Commissions' },
    {
      key: '1013000156',
      name: '1013000156 - Office of Communication &amp; Mktg'
    }
  ];
  employment_Types = [
    { key: 'student', name: 'Student' },
    { key: 'federal', name: 'Federal Work Study' },
    { key: 'graduate', name: 'Graduate Assistant' },
    { key: 'hourly', name: 'Hourly Temporary' },
    { key: 'monthly', name: 'Monthly Temporary' },
    { key: 'lecturer-11', name: 'L11 Lecturer' },
    { key: 'lecturer-12', name: 'L12 Lecturer' },
    { key: 'house-h12', name: 'House Staff' }
  ];

  payPeriods = [
    { key: 'Hourly', name: 'Hourly' },
    { key: 'Monthly', name: 'Monthly' }
  ];

  graduate_positions = [
    { key: 'GF', name: 'Graduate Fellow' },
    { key: 'GTA', name: 'Graduate Teaching Assistant' },
    { key: 'GRA', name: 'Graduate Research Assistant' },
    { key: 'GSA', name: 'Graduate Service Assistant' }
  ];

  candidate_hire__details: any = {
    created_on: '',
    last_modified: '',
    etag: 'ffdbb62e16aadb9c8478b41b2485433e67775c7b4c6c45da3acb3f098d55f88c',
    employee_id: '',
    first_name: '',
    middle_name: '',
    last_name: '',
    email_address: '',
    employment_type: '',
    start_date: '',
    pay_period: '',
    pay_rate: '',
    position_number: '',
    department_number: '',
    department_name: '',
    position_funding_sources: [
      {
        speedtype: '',
        percentage: ''
      }
    ],
    hours_per_week: '',
    graduate_position_type: '',
    cbc_funding_source: '',
    comment: '',
    wsan_award: '',
    supervisor: '',
    supervisor_email: '',
    cbc_needed: true,
    end_date: ''
  };
  constructor(
    private router: Router,
    private hireService: HireService,
    private changeDetectorRef: ChangeDetectorRef,
    private formBuilder: FormBuilder
  ) {}

  ngOnInit() {
    this.form = this.formBuilder.group({
      candidate_group: new FormGroup({
        employee_id: new FormControl('', Validators.minLength(2)),
        first_name: new FormControl('', Validators.required),
        middle_name: new FormControl(''),
        last_name: new FormControl('', Validators.required),
        email_address: new FormControl('', Validators.email)
      }),

      job_group: new FormGroup({
        employment_type: new FormControl('', Validators.required),
        position_number: new FormControl(''),
        hiring_department: new FormControl('', Validators.required),
        graduate_position_type: new FormControl(''),
        pay_rate: new FormControl('', [Validators.required, Validators.min(0)]),
        pay_period: new FormControl('', Validators.required),
        hours_per_week: new FormControl('', Validators.required)
      }),

      funding_group: new FormGroup({
        criminal_bg_chk: new FormControl('', Validators.required),
        position_funding_sources:  new FormArray([this.initY()])
        
      }),

      app_group: new FormGroup({
        app_start_date: new FormControl('', Validators.required),
        app_end_date: new FormControl('') 
      }),

      admin_group: new FormGroup({
        supervisor_name: new FormControl('', Validators.required),
        supervisor_email: new FormControl('', [
          Validators.required,
          Validators.email
        ]),
        comment: new FormControl('')
      })
    });
  }

  initY() {
    return this.formBuilder.group({
      'speedtype': ['', [Validators.required]],
      'percentage': ['', [Validators.required]],
    })
  }
  prevStep(tab: any): void {
    this.step = tab;
    const page = { tab: tab, isPrev: true };
    this.tabToShow(page);
  }
  nextStep(tab: any): void {
    if (this.checkFormValid()) {
      this.step = tab;
      const page = { tab: tab, isPrev: false, formVal: this.form.value };
      this.tabToShow(page);
    }
  }

  checkFormValid(): boolean {
    if (this.step === 1) {
      return this.form.controls.candidate_group.valid;
    } else if (this.step === 2) {
      return this.form.controls.job_group.valid;
    } else if (this.step === 3) {
      return this.form.controls.funding_group.valid;
    } else if (this.step === 4) {
      return this.form.controls.app_group.valid;
    } else if (this.step === 5) {
      return this.form.controls.admin_group.valid;
    }
  }

  validateAllFormFields(formGroup) {
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field);
      if (control instanceof FormControl) {
        control.markAsTouched({ onlySelf: true });
        return false;
      } else if (control instanceof FormGroup) {
        this.validateAllFormFields(control);
      }
    });
  }

  expand(tab: any): void {
    //  this.form.get('candidateGroup.employee_id')
    this.step = tab;
  }
  foucsPanel(tab) {
    this.step = tab;
  }
  addItem(): void {
    this.items = this.form.get('items') as FormArray;
    this.items.push(this.initY());
  }
  addFundingSource() {
      this.items = <FormArray>this.form.get('funding_group').get('position_funding_sources');
      this.items.push(this.initY());
  }
  removeFundingSource(i) {
    this.items.removeAt(i);
  }
  addEvent(type: string, event: MatDatepickerInputEvent<Date>) {
    this.isEndDateDisable = false;
    this.start_date = event.value;
  }

  public tabToShow(e) {
    if (!e.isPrev) {
      if (e.tab == 2) {
        this.candidate_hire__details.created_on = this.today.toISOString();
        this.candidate_hire__details.last_modified = this.today.toISOString();
        this.candidate_hire__details.employee_id =
          e.formVal.candidate_group.employee_id;
        this.candidate_hire__details.first_name =
          e.formVal.candidate_group.first_name;
        this.candidate_hire__details.middle_name =
          e.formVal.candidate_group.middle_name;
        this.candidate_hire__details.last_name =
          e.formVal.candidate_group.first_name;
        this.candidate_hire__details.email_address =
          e.formVal.candidate_group.email_address;
      } else if (e.tab == 3) {
        this.candidate_hire__details.employment_type =
          e.formVal.job_group.employment_type;
        this.candidate_hire__details.graduate_position_type =
          e.formVal.job_group.graduate_position_type;
        this.candidate_hire__details.position_number =
          e.formVal.job_group.position_number;

        this.candidate_hire__details.department_number =
          e.formVal.job_group.hiring_department;
        this.candidate_hire__details.department_name =
          e.formVal.job_group.hireDepName;

        this.candidate_hire__details.pay_rate = e.formVal.job_group.pay_rate;
        this.candidate_hire__details.pay_period =
          e.formVal.job_group.pay_period;
        this.candidate_hire__details.hours_per_week =
          e.formVal.job_group.hours_per_week;
      } else if (e.tab == 4) {
        this.candidate_hire__details.position_funding_sources = [
          {
            speedtype: e.formVal.funding_group.speedtype,
            percentage: e.formVal.funding_group.percentage
          }
        ];
        if(this.multiValue){
          this.candidate_hire__details.position_funding_sources.push(this.position_funding_sources);
        }
        this.candidate_hire__details.cbc_funding_source =
          e.formVal.criminal_bg_chk;
      } else if (e.tab == 5) {
        if (e.formVal.app_group.app_start_date) {
          this.candidate_hire__details.start_date = e.formVal.app_group.app_start_date
            .toISOString()
            .substring(0, 10);
        }
        if (e.formVal.app_group.app_end_date) {
          this.candidate_hire__details.end_date = e.formVal.app_group.app_end_date
            .toISOString()
            .substring(0, 10);
        }
      } else if (e.tab == 6) {
        this.candidate_hire__details.supervisor =
          e.formVal.admin_group.supervisor_name;
        this.candidate_hire__details.supervisor_email =
          e.formVal.admin_group.supervisor_email;
        this.candidate_hire__details.comment = e.formVal.admin_group.comment;
        // call service
        this.hireService
          .setOnboardingHire(this.candidate_hire__details)
          .subscribe(res => {
            this.router.navigate(['/home', { success: true }]);
          });
      }
    }
    this.changeDetectorRef.detectChanges();
    window.scrollTo(0, 0);
  }
  displayFieldCss(field: string) {
    return {
      'has-error': this.isFieldValid(field),
      'has-feedback': this.isFieldValid(field)
    };
  }

  isFieldValid(field: string) {
    // console.log(!this.form.get(field).valid && this.form.get(field).touched);
    return !this.form.get(field).valid && this.form.get(field).touched;
  }
  finishStep(tab) {
    if (this.form.valid) {
      this.errorMessage = '';
      const sendToParent = { tab: tab, formVal: this.form.value };
      this.tabToShow(sendToParent);
    } else {
      this.validateAllFormFields(this.form);
      this.errorMessage =
        'There were issues with your submission! Please correct the fields marked in red in the form below:';
      this.changeDetectorRef.markForCheck();
    }
  }
  showAdditionalInfo(event) {
    this.graduate_position_val = event.target.value;
  }
  employment(event) {
    if (event.value == 'graduate') {
      this.display_graduate_sec = true;
    } else {
      this.display_graduate_sec = false;
    }
  }
  private getHireDeptName(id) {
    const len = this.hiring_department.length;
    for (let i = 0; i < len; i++) {
      if (this.hiring_department[i].key == id) {
        return this.hiring_department[i].name;
      }
    }
  }
  radioValue(event) {
    this.graduate_position_val = event.value;
  }
}
