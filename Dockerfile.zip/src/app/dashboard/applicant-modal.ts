export class ApplicantModel {
        TicketID?: string 
        SubmittedDate?: string;
        SubmittedByName?:string;
        SubmittedByEmail?:string;
        status?:string;
        type?:string;
        applicantName?:string;
        applicantEmail?:string;
        employeeid?: string;
        hiredate?: string;
        department?: string;
        submitted?: string;
        position?: number;
        cbcchecked?:boolean; 
        cbcreceived?:boolean;
        currentstep?:boolean;
        EmploymentType?:boolean;
        CBCFundingSources?:boolean;
        PositionFundingSources?:boolean;
        PositionFundingPercentage?: number;
        RateOfPay?: number;
        HoursPerWeek?: number;
        HiringDepartment?: string;
        StartDate?: string;
        EndDate?: string;
        CBCNeeded?: string;
        WSANAward?: string;
        Comment?: string
}