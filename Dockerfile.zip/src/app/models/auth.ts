import {Employee} from './employee';

export interface AuthPayload {
  employee: Employee;
  roles: string[];
  token: string;
  user_id: string;
}
