import { Injectable } from '@angular/core';
import { AbstractControl, ValidatorFn } from '@angular/forms';
@Injectable({
  providedIn: 'root'
})
export class CustomValidationService {
  constructor() { }
  checklength(ssn: number) {
    if(ssn){
      if (ssn.toString().length < 9) {
        console.log('Shiva true');
          return true;
      }
      console.log('Shiva false')
      return null;
    }

}

}
