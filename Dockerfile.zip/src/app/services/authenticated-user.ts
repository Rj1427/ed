import {Injectable} from '@angular/core';
import {BehaviorSubject, Observable} from 'rxjs';
import {Employee} from '../models/employee';
import {AuthPayload} from '../models/auth';
import {Router} from '@angular/router';

@Injectable()
export class AuthenticatedUserService {

  private _user: BehaviorSubject<Employee> = new BehaviorSubject<Employee>(undefined);
  private _api_token: string;
  private _roles: string[];
  private _isLoggedIn = false;
  user: Observable<Employee>;

  constructor (private router: Router) {
    this.user = this._user.asObservable();
  }
  get isLoggedIn(): boolean {
    return this._isLoggedIn;
  }

  get roles(): string[] {
    return this._roles;
  }

  get api_token(): string {
    return this._api_token;
  }

  processLogin(payload: AuthPayload) {
    this._user.next(payload.employee);
    this._api_token = payload.token;
    this._roles = payload.roles;
    this._isLoggedIn = true;
  }
  // By Shiva
  checkLoggedIn(): boolean{
    return this._isLoggedIn;
  }
  // By Shiva
  getUserRole(){
    return this._roles;
  }
  logout() {
    console.log('logout called');
    this._isLoggedIn = false;
    this._api_token = '';
    this._roles = [];
    this._user.next(undefined);
    this.router.navigate(['/login']);
  }
}
