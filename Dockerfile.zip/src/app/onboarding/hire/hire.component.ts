import { Component, OnInit } from '@angular/core';
import { HireService } from './hire.service';
import { formatDate } from '@angular/common';
import { Router } from '@angular/router';
@Component({
  selector: 'app-hire',
  templateUrl: './hire.component.html',
  styleUrls: ['./hire.component.scss']
})
export class HireComponent implements OnInit {
  tabToDisplay: number = 1;

  candidate_hire__details: any = {
    created_on: '',
    last_modified: '',
    etag: 'ffdbb62e16aadb9c8478b41b2485433e67775c7b4c6c45da3acb3f098d55f88c',
    employee_id: '',
    first_name: '',
    middle_name: '',
    last_name: '',
    email_address: '',
    employment_type: '',
    start_date: '',
    pay_period: '',
    pay_rate: '',
    position_number: '',
    department_number: '',
    department_name: '',
    position_funding_sources: [
      {
        speedtype: '',
        percentage: ''
      }
    ],
    hours_per_week: '',
    graduate_position_type: '',
    cbc_funding_source: '',
    comment: '',
    wsan_award: '',
    supervisor: '',
    supervisor_email: '',
    cbc_needed: true,
    end_date: ''
  };
  today = new Date();
  constructor(private router: Router, private hireService: HireService) {}
  ngOnInit() {
    this.hireService.setCandidate(this.candidate_hire__details);
  }
  tabOnClick(e) {
    this.tabToDisplay = e;
    window.scrollTo(0, 0);
  }
  public tabToShow(e) {
    if (!e.isPrev) {
      if (e.tab == 2) {
        this.candidate_hire__details.created_on = this.today.toISOString();
        this.candidate_hire__details.last_modified = this.today.toISOString();
        this.candidate_hire__details.employee_id = e.formVal.employee_id;
        this.candidate_hire__details.first_name = e.formVal.first_name;
        this.candidate_hire__details.middle_name = e.formVal.middle_name;
        this.candidate_hire__details.last_name = e.formVal.first_name;
        this.candidate_hire__details.email_address = e.formVal.email_address;
      } else if (e.tab == 3) {
        this.candidate_hire__details.employment_type =
          e.formVal.employment_type;
        this.candidate_hire__details.graduate_position_type =
          e.formVal.graduate_position_type;
        this.candidate_hire__details.position_number =
          e.formVal.position_number;

        this.candidate_hire__details.department_number =
          e.formVal.hiring_department;
        this.candidate_hire__details.department_name = e.formVal.hireDepName;

        this.candidate_hire__details.pay_rate = e.formVal.pay_rate;
        this.candidate_hire__details.pay_period = e.formVal.pay_period;
        this.candidate_hire__details.hours_per_week = e.formVal.hours_per_week;
      } else if (e.tab == 4) {
        this.candidate_hire__details.position_funding_sources = [
          {
            speedtype: e.formVal.speedtype,
            percentage: e.formVal.percentage
          }
        ];
        this.candidate_hire__details.cbc_funding_source =
          e.formVal.criminal_bg_chk;
      } else if (e.tab == 5) {
        this.candidate_hire__details.start_date = new Date(
          e.formVal.app_start_date.year,
          e.formVal.app_start_date.month - 1,
          e.formVal.app_start_date.day + 1
        )
          .toISOString()
          .substring(0, 10);
        this.candidate_hire__details.end_date = new Date(
          e.formVal.app_end_date.year,
          e.formVal.app_end_date.month - 1,
          e.formVal.app_end_date.day + 1
        )
          .toISOString()
          .substring(0, 10);
      } else if (e.tab == 6) {
        this.candidate_hire__details.supervisor = e.formVal.supervisor_name;
        this.candidate_hire__details.supervisor_email =
          e.formVal.supervisor_email;
        this.candidate_hire__details.comment = e.formVal.comment;
        //call service
        this.hireService
          .setOnboardingHire(this.candidate_hire__details)
          .subscribe(res => {
            this.router.navigate(['/home', { success: true }]);
          });
          this.candidate_hire__details = {};
          this.hireService.setCandidate(this.candidate_hire__details);
      }
    }
    this.hireService.setCandidate(this.candidate_hire__details);
    this.tabToDisplay = e.tab;
    window.scrollTo(0, 0);
  }
}
