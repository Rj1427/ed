import { Component, OnInit, EventEmitter, Output, Input } from '@angular/core';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {
  @Output() tabsl: EventEmitter<any> = new EventEmitter<any>();
  @Input() tab = 0;
  sl = 1;
  constructor() { }

  ngOnInit() {
    
  }
  goToTab(tabno: any): void {
    this.sl = tabno;
   this.tabsl.emit(tabno);
 }
}
