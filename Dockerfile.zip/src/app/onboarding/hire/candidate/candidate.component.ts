import { HireService } from './../hire.service';
import { Router } from '@angular/router';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormControl,
  FormGroupDirective,
  NgForm
} from '@angular/forms';
import { Component, OnInit, EventEmitter, Output, Input } from '@angular/core';
import { MatTabsModule } from '@angular/material';
import {ErrorStateMatcher} from '@angular/material/core';

/** Error when invalid control is dirty, touched, or submitted. */
export class MyErrorStateMatcher implements ErrorStateMatcher {
  isErrorState(control: FormControl | null, form: FormGroupDirective | NgForm | null): boolean {
    const isSubmitted = form && form.submitted;
    return !!(control && control.invalid && (control.dirty || control.touched || isSubmitted));
  }
}

@Component({
  selector: 'app-candidate',
  templateUrl: './candidate.component.html',
  styleUrls: ['./candidate.component.scss']
})
export class CandidateComponent implements OnInit {
  @Output() tabindex: EventEmitter<any> = new EventEmitter<any>();
  @Input() candidate;
  form: FormGroup;
  step = 1;
  displayMonths = 3;
  hiring_department = [
    { key: '1010000156', name: '1010000156 - Office of the President' },
    { key: '1010000184', name: '1010000184 -  Office of the President-GIE' },
    { key: '1011000156', name: '1010000156 -  Admin Supp Serv-Stu Serv' },
    { key: '1017000156', name: '1017000156 - Boards - Institutional Support' },
    { key: '1018000144', name: '1018000144 - Commissions' },
    {
      key: '1013000156',
      name: '1013000156 - Office of Communication &amp; Mktg'
    }
  ];
  employment_Types = [
    { key: 'student', name: 'Student' },
    { key: 'federal', name: 'Federal Work Study' },
    { key: 'graduate', name: 'Graduate Assistant' },
    { key: 'hourly', name: 'Hourly Temporary' },
    { key: 'monthly', name: 'Monthly Temporary' },
    { key: 'lecturer-11', name: 'L11 Lecturer' },
    { key: 'lecturer-12', name: 'L12 Lecturer' },
    { key: 'house-h12', name: 'House Staff' }
  ];

  payPeriods = [
    { key: 'Hourly', name: 'Hourly' },
    { key: 'Monthly', name: 'Monthly' }
  ];

  matcher = new MyErrorStateMatcher();
  constructor(private router: Router, private formBuilder: FormBuilder, private hireService: HireService) {}

  ngOnInit() {
    const candidateDetails = this.hireService.candidateDetails;
    this.form = this.formBuilder.group({
      employee_id: candidateDetails.employee_id,
      first_name: [candidateDetails.first_name, Validators.required],
      middle_name: candidateDetails.middle_name,
      last_name: [candidateDetails.last_name, Validators.required],
      email_address: [candidateDetails.email_address, [Validators.required, Validators.email]],
      employment_type: [this.candidate.employment_type, Validators.required],
      position_number: this.candidate.position_number,
      hiring_department: [
        this.candidate.department_number,
        Validators.required
      ],
      graduate_position_type: this.candidate.graduate_position_type,
      pay_rate: [this.candidate.pay_rate, Validators.required],
      pay_period: [this.candidate.pay_period, Validators.required],
      hours_per_week: [this.candidate.hours_per_week, Validators.required],
      criminal_bg_chk: [null, Validators.required],
      speedtype: null,
      percentage: null,
      app_start_date: [null, Validators.required],
      app_end_date: null,
      supervisor_name: [null, Validators.required],
      supervisor_email: [null, [Validators.required, Validators.email]],
      comment: null
    });
  }

  isFieldValid(field: string) {
    return !this.form.get(field).valid && this.form.get(field).touched;
  }

  displayFieldCss(field: string) {
    return {
      'has-error': this.isFieldValid(field),
      'has-feedback': this.isFieldValid(field)
    };
  }

  validateAllFormFields(formGroup: FormGroup) {
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field);
      if (control instanceof FormControl) {
        control.markAsTouched({ onlySelf: true });
        return false;
      } else if (control instanceof FormGroup) {
        this.validateAllFormFields(control);
      }
    });
  }

  setStep(index: number) {
    this.step = index;
  }

  nextStep(tab: number) {
      const sendToParent = { tab: tab, formVal: this.form.value };
      this.step++;
      this.tabindex.emit(sendToParent);
  }

  finishStep(tab: number) {
    if (this.form.valid) {
      const sendToParent = { tab: tab, formVal: this.form.value };
      this.step++;
      this.tabindex.emit(sendToParent);
    } else {
      this.validateAllFormFields(this.form);
    }

  }

  prevStep() {
    this.step--;
  }

}
