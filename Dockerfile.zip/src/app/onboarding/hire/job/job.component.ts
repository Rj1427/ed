import { Router } from '@angular/router';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormControl
} from '@angular/forms';
import { Component, OnInit, EventEmitter, Output, Input } from '@angular/core';
import { FieldErrorDisplayComponent } from '../../field-error-display/field-error-display.component';
import { HireComponent } from '../hire.component'
import { compileComponentFromMetadata } from '@angular/compiler';

@Component({
  providers: [HireComponent],
  selector: 'app-job',
  templateUrl: './job.component.new.html',
  styleUrls: ['./job.component.css']
})
export class JobComponent implements OnInit {
  tabToDisplay: number = 1;
  @Output() tabindex: EventEmitter<any> = new EventEmitter<any>();
  //@Output() tabindex = new EventEmitter<any>();
 
  @Input() candidate;
  form: FormGroup;
  graduate_position_val: string;
  display_graduate_sec: boolean = false;
  hiring_department = [
    {id:"1010000156", name:"1010000156 - Office of the President"},
    {id:"1010000184", name:"1010000184 -  Office of the President-GIE"},
    {id:"1011000156", name:"1010000156 -  Admin Supp Serv-Stu Serv"},
    {id:"1017000156", name:"1017000156 - Boards - Institutional Support"},
    {id:"1018000144", name:"1018000144 - Commissions"},
    {id:"1013000156", name:"1013000156 - Office of Communication &amp; Mktg"}
  ];

  constructor(private router: Router, private formBuilder: FormBuilder ) { }


  ngOnInit() {
    this.form = this.formBuilder.group({
      employment_type: [this.candidate.employment_type, Validators.required], 
      position_number: null,
      hiring_department: [null, Validators.required],
      graduate_position_type: null,
      pay_rate:  [null, Validators.required],
      //pay_rate:  null,
      pay_period: [null, Validators.required],
      hours_per_week:  [null, Validators.required]
    });
    this.setVal(this.candidate)
  }



  setVal(candidateDetails: any){
    this.form.controls['employment_type'].setValue(candidateDetails.employment_type,{onlySelf: true});
    // this.form.get('employment_type').setValue(candidateDetails.employment_type);
    this.form.get('position_number').setValue(candidateDetails.position_number);
    this.form.get('hiring_department').setValue(candidateDetails.hiring_department);
    this.form.get('graduate_position_type').setValue(candidateDetails.graduate_position_type);
    this.form.get('pay_rate').setValue(candidateDetails.pay_rate);
    this.form.get('pay_period').setValue(candidateDetails.pay_period);
    this.form.get('hours_per_week').setValue(candidateDetails.hours_per_week);
  }
  showAdditionalInfo(event) {
    this.graduate_position_val = event.target.value;
    this.tabindex.emit(this.tabToDisplay);
  }
  employment(event) {
    if(event.target.value == 'graduate'){
      this.display_graduate_sec = true;
    }else{
      this.display_graduate_sec = false; 
    }
  }
  private getHireDeptName(id){
    let len = this.hiring_department.length;
    for(let i = 0; i<len; i++){
      if(this.hiring_department[i].id == id){
        return this.hiring_department[i].name;
      }
    }
  }
  goToPrev(tab: any): void {
     this.tabindex.emit({tab: tab, isPrev: true});
  }
  goToNext(tab: any): void {
   if (this.form.valid) {
     let hireDepName = this.getHireDeptName(this.form.value.hiring_department);
     this.form.value.hireDepName = hireDepName;

    let sendToParent = {tab:tab,formVal:this.form.value};
    this.tabindex.emit(sendToParent);
   } else {
     this.validateAllFormFields(this.form);
   }
 }
  isFieldValid(field: string) {
    //console.log(!this.form.get(field).valid && this.form.get(field).touched);
   return !this.form.get(field).valid && this.form.get(field).touched;
 }
 
 displayFieldCss(field: string) {
   return {
     'has-error': this.isFieldValid(field),
     'has-feedback': this.isFieldValid(field)
   };
 }
 validateAllFormFields(formGroup: FormGroup) {    
   Object.keys(formGroup.controls).forEach(field => {  
     const control = formGroup.get(field);            
     if (control instanceof FormControl) {             
       control.markAsTouched({ onlySelf: true });
       return false;
     } else if (control instanceof FormGroup) {        
       this.validateAllFormFields(control);
     }
   });
 }

 
}
