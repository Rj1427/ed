import { Component, OnInit, EventEmitter, Output, ViewChild } from '@angular/core';

@Component({
  selector: 'app-veteran-status',
  templateUrl: './veteran-status.component.html',
  styleUrls: ['./veteran-status.component.css']
})
export class VeteranStatusComponent implements OnInit {
  @Output() tabindex: EventEmitter<any> = new EventEmitter<any>();
  veteran_status: any = false;
  tochecked = false;
  @ViewChild('Chkbox1') chk1;
  @ViewChild('Chkbox2') chk2;
  @ViewChild('Chkbox3') chk3;
  @ViewChild('Chkbox4') chk4;
  constructor() { }

  ngOnInit() {
  }
  goToPrev(tab: any): void {
    this.tabindex.emit(tab);
  }
  goToNext(tab: any): void {
   //if (this.form.valid) {
    this.tabindex.emit(tab);
  //  } else {
  //    this.validateAllFormFields(this.form); 
  //  }
 }
 unselectAll(e) {
  //this.tochecked = false;
 // console.log(e);
 this.chk1.nativeElement.checked = false;
 this.chk2.nativeElement.checked = false;
 this.chk3.nativeElement.checked = false;
 this.chk4.nativeElement.checked = false;
 }
}
