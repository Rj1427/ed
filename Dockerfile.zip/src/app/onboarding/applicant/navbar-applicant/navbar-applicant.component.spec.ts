import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NavbarApplicantComponent } from './navbar-applicant.component';

describe('NavbarApplicantComponent', () => {
  let component: NavbarApplicantComponent;
  let fixture: ComponentFixture<NavbarApplicantComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NavbarApplicantComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NavbarApplicantComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
