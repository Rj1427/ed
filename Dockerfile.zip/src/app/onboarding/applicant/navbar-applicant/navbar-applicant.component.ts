import { Component, OnInit, EventEmitter, Output, Input } from '@angular/core';

@Component({
  selector: 'app-navbar-applicant',
  templateUrl: './navbar-applicant.component.html',
  styleUrls: ['./navbar-applicant.component.css']
})
export class NavbarApplicantComponent implements OnInit {  
  @Output() tabsl: EventEmitter<any> = new EventEmitter<any>();
  @Input() tab = 0;
  sl = 1;
  constructor() { }

  ngOnInit() {
  }
  goToTab(tabno: any): void {
    this.sl = tabno;
   this.tabsl.emit(tabno);
 }
}


