import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormControl
} from '@angular/forms';

@Component({
  selector: 'app-addresses',
  templateUrl: './addresses.component.html',
  styleUrls: ['./addresses.component.css']
})
export class AddressesComponent implements OnInit {
  form: FormGroup;
  different_mailing_address = 'no';
  addressDetails = [];
  @Output() tabindex: EventEmitter<any> = new EventEmitter<any>();

  constructor(private formBuilder: FormBuilder) { }

  ngOnInit() {
    this.form = this.formBuilder.group({
      address_1: new FormControl('', [        
        Validators.required
    ]),
address_2: '',
address_city: new FormControl('', [
        Validators.pattern("^[a-zA-Z]*$"),
        Validators.required
    ]),
address_state: new FormControl('', [
  Validators.required
]),
address_zipcode: new FormControl('', [
        Validators.pattern("^[0-9]*$"),
        Validators.required
    ]),
different_applicant_mailing_address: '',
mail_address_1: new FormControl('', [       
        Validators.required
    ]),
mail_address_2: new FormControl('', [
        Validators.pattern("^[a-zA-Z]*$"),
        Validators.required
    ]),
mail_address_city: new FormControl('', [
        Validators.pattern("^[a-zA-Z]*$"),
        Validators.required
    ]),
mail_address_state: '',
mail_address_zipcode: new FormControl('', [
        Validators.pattern("^[a-zA-Z]*$"),
        Validators.required
    ]),
emergency_contact: '',
emergency_relationship:'',
different_emergency_contact_address: '',
emergency_address_1: '',
emergency_city: '',
emergency_state: '',
emergency_zipcode: '',
emergency_cont_tel: '',
emergency_cont_tel_type: '',
    });
  }
  differentMailingAddress(e) {
    this.different_mailing_address = e.target.value;
  }
  addNewEmergencyDetails() {
  
    this.addressDetails.push({tel: '', addType: ''});
    //console.log(this.addressDetails);
    window.scrollTo(0,document.body.scrollHeight);

  }
  goToPrev(tab: any): void {
    this.tabindex.emit(tab);
  }
  goToNext(tab: any): void {
   if (this.form.valid) {
    this.tabindex.emit(tab);
   } else {
     this.validateAllFormFields(this.form); 
  }
   }
 
  removeNewEmergencyDetails(i) {
    this.addressDetails.splice(i,1);
  }

    // Validation code
    isFieldValid(field: string) {
      console.log(!this.form.get(field).valid && this.form.get(field).touched);
     return !this.form.get(field).valid && this.form.get(field).touched;
   }
   
   displayFieldCss(field: string) {
     return {
       'has-danger': this.isFieldValid(field)
      //  'has-success': this.isFieldValid(field)
     };
   }
   validateAllFormFields(formGroup: FormGroup) {    
     Object.keys(formGroup.controls).forEach(field => {  
       const control = formGroup.get(field);  
       if (control instanceof FormControl) { 
         control.markAsTouched({ onlySelf: true });
         return false;
       } else if (control instanceof FormGroup) { 
         this.validateAllFormFields(control);
       }
     });
   }
}
