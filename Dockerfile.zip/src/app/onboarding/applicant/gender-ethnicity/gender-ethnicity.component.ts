import { Component, OnInit, EventEmitter, Output } from '@angular/core';

@Component({
  selector: 'app-gender-ethnicity',
  templateUrl: './gender-ethnicity.component.html',
  styleUrls: ['./gender-ethnicity.component.css']
})
export class GenderEthnicityComponent implements OnInit {
  @Output() tabindex: EventEmitter<any> = new EventEmitter<any>();
  constructor() { }

  ngOnInit() {
  }
  goToPrev(tab: any): void {
    this.tabindex.emit(tab);
  }
  goToNext(tab: any): void {
   //if (this.form.valid) {
    this.tabindex.emit(tab);
  //  } else {
  //    this.validateAllFormFields(this.form); 
  //  }
 }
}
