import { Component, OnInit, EventEmitter, Output } from '@angular/core';

@Component({
  selector: 'app-disability-status',
  templateUrl: './disability-status.component.html',
  styleUrls: ['./disability-status.component.css']
})
export class DisabilityStatusComponent implements OnInit {
  @Output() tabindex: EventEmitter<any> = new EventEmitter<any>();
  constructor() { }

  ngOnInit() {
  }
  goToPrev(tab: any): void {
    this.tabindex.emit(tab);
  }
  goToNext(tab: any): void {
  // if (this.form.valid) {
    this.tabindex.emit(tab);
  //  } else {
  //    this.validateAllFormFields(this.form); 
  //  }
 }

}
