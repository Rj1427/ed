import { Component, OnInit} from '@angular/core';

@Component({
  selector: 'app-applicant',
  templateUrl: './applicant.component.html',
  styleUrls: ['./applicant.component.css']
})
export class ApplicantComponent implements OnInit {
 tabToDisplay: number = 1;
  constructor() { }

  ngOnInit() {
  }
  public tabToShow(e)  {
    this.tabToDisplay = e;
    window.scrollTo(0, 0);
  }
}
