import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { OnboardingModule } from './onboarding/onboarding.module';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
import { HelpComponent } from './help/help.component';
import {TravelComponent } from './travel/travel.component';
import { LeaveComponent } from './leave/leave.component';
import { OnboardingComponent } from './onboarding/onboarding.component';
import { TimesheetComponent } from './timekeeping/timesheet/timesheet.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { TimekeepingComponent } from './timekeeping/timekeeping.component';
import { TimesheetPrintViewComponent } from './timekeeping/timesheet-print-view/timesheet-print-view.component';
import { ApproveComponent } from './timekeeping/approve/approve.component';

import { ApplicantComponent } from './onboarding/applicant/applicant.component';
import { HireComponent } from './onboarding/hire/hire.component';
import { AuthGuard } from './guards/auth.guard';
import { EditTimesheetComponent } from './timekeeping/edit-timesheet/edit-timesheet.component';

const routes: Routes = [
  {path: '', redirectTo: '/login', pathMatch: 'full'},
  {path: 'login', component: LoginComponent},
  {path: 'home', component: HomeComponent},
  {path: 'help', component: HelpComponent},
  {path: 'travel', component: TravelComponent},
  {path: 'leave', component: LeaveComponent},
  {path: 'dashboard', component: DashboardComponent} ,

  {
  path: 'onboarding',
  component: OnboardingComponent,
  // canActivate: [AuthGuard],
  children: [
    {
      path: '',
    // canActivateChild: [AuthGuard],
      children: [
        { path: '', component: HireComponent },
        { path: 'applicant', component: ApplicantComponent },
        { path: 'hire', component: HireComponent }
      ]
    }
  ]
  },
  {
    path: 'timekeeping',
    //component: TimekeepingComponent,
    children: [
      {
        path: '',
        children: [
          { path: '', component: TimesheetComponent },
          { path: 'timesheet', component: TimesheetComponent },
          { path: 'timesheet-print-view', component: TimesheetPrintViewComponent },
          { path: 'approve', component: ApproveComponent },
          { path: 'edit-timesheet', component: EditTimesheetComponent }          
        ]
      }
    ]
    },
  {path: '**', component: LoginComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {
}

export const routingComponents = [LoginComponent, HomeComponent, HelpComponent, TravelComponent, LeaveComponent, OnboardingComponent, TimekeepingComponent];
