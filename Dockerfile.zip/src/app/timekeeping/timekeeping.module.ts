import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {DialogModule} from 'primeng/dialog';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import {CalendarModule} from 'primeng/calendar';
import {TableModule} from 'primeng/table';


// import {ToggleButtonModule} from 'primeng/togglebutton';
import { UiSwitchModule } from 'ngx-toggle-switch';
import {DropdownModule} from 'primeng/dropdown';
import { TimekeepingRoutingModule } from './timekeeping-routing.module';
import { TimekeepingComponent } from './timekeeping.component';
import { TimesheetComponent } from './timesheet/timesheet.component';
import { TimesheetPrintViewComponent } from './timesheet-print-view/timesheet-print-view.component';
import { ApproveComponent } from './approve/approve.component';
import { TimeViewComponent } from './Shared/time-view/time-view.component';
import { EditTimesheetComponent } from './edit-timesheet/edit-timesheet.component';


@NgModule({
  imports: [
    CommonModule,
    DialogModule,
    FormsModule,
    ReactiveFormsModule,
    CalendarModule,
    UiSwitchModule,
    TimekeepingRoutingModule,
    DropdownModule,
    TableModule
  ],
  declarations: [TimekeepingComponent, TimesheetComponent, TimesheetPrintViewComponent, ApproveComponent, TimeViewComponent, EditTimesheetComponent],
  exports: [TimekeepingComponent, TimesheetComponent]
})
export class TimekeepingModule { }
