import { Component, OnInit } from '@angular/core';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormControl
} from '@angular/forms';

@Component({
  selector: 'app-timesheet',
  templateUrl: './timesheet.component.html',
  styleUrls: ['./timesheet.component.css']
})
export class TimesheetComponent implements OnInit {
  // addTime: FormGroup;
  // addLeave: FormGroup;
  addTimeDialog: boolean = false;
  showAddLeave: boolean = false;
  shiftDifferential: boolean = true;
  standBy: boolean = false;
  callInBack: boolean = false;
   time = new Date();
   outTime: string;
   inTime: string;
  showWeek1: boolean = true;
  showWeek2: boolean = false;
  showTotal: boolean = false;
  updateSupervisorDialog: boolean = false;
  supervisor;
  constructor(private formBuilder: FormBuilder) {
  this.supervisor = [
    {label: 'MR X', value: 'MR X'},
    {label: 'MR Y', value: 'MR Y'},
    {label: 'MR Z', value: 'MR Z'},
    {label: 'MR John', value: 'MR John'},
    {label: 'MR Doe', value: 'MR Doe'}
  ]
   }

  ngOnInit() {
    // this.addTime = this.formBuilder.group({
    //   time_in: new FormControl({value: null}),
    //   time_out: new FormControl({value: null}),
    //   shift_differential: new FormControl(),
    //   stand_by: new FormControl(),
    //   call_in_back: new FormControl()      
    // });
    // this.addLeave = this.formBuilder.group({
    //   leave_type: new FormControl(),
    //   leave_hour: new FormControl(),
    //   fmla: new FormControl()
    // });

   // this.newTime = new Date().getTime();
   // this.newTime = new Date('2018-04-12T04:56:20.744Z');
    // this.addTime.controls[ 'time_in' ].setValue(this.newTime);
    
    // this.outTime = this.getCurrentTime();
    // this.inTime = this.getCurrentTime();
  }
   getCurrentTime(time) {
    var hours = new Date().getHours();
    var minutes = new Date().getMinutes();
    var ampm = hours >= 12 ? 'pm' : 'am';
    hours = hours % 12;
    hours = hours ? hours : 12; // the hour '0' should be '12'
    var mins = minutes < 10 ? '0'+minutes : minutes;
    var strTime = hours + ':' + mins + ' ' + ampm;
    if(time == 'inTime')
      this.inTime = strTime;
    else
      this.outTime = strTime;
  }
  weekOneClick() {
    this.showWeek1 = true;
    this.showWeek2 = false;
  }
  weekTwoClick() {
    this.showWeek1 = false;
    this.showWeek2 = true;
  }
  showTotalClick() {
    this.showWeek1 = false;
    this.showWeek2 = false;
    this.showTotal = true;
  }

  updateSupervisor(){
    this.updateSupervisorDialog = true;
  }
  hideupdateSupervisorDialog(){
    this.updateSupervisorDialog = false;
  }
  addTimeModal(){
    this.addTimeDialog = true;
  }
  addLeaveModal(){
    this.showAddLeave = true;
  }
  hideAddTimeDialog(){
    this.addTimeDialog = false;
  }
  hideLeaveDialog(){
    this.showAddLeave = false;
  }
}
