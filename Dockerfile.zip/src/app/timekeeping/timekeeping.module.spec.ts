import { TimekeepingModule } from './timekeeping.module';

describe('TimekeepingModule', () => {
  let timekeepingModule: TimekeepingModule;

  beforeEach(() => {
    timekeepingModule = new TimekeepingModule();
  });

  it('should create an instance', () => {
    expect(timekeepingModule).toBeTruthy();
  });
});
