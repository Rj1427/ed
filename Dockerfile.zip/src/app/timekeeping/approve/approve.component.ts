import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-approve',
  templateUrl: './approve.component.html',
  styleUrls: ['./approve.component.css']
})
export class ApproveComponent implements OnInit {
  name_of_detail_emp: any;
  detail_emp_div: boolean = false;
  emp_details_record: Array<any>;
  cols_details: Array<any>;
  cols_historical: Array<any>;
  historicalDetails: Array<any>;
  timesheetData: boolean = false;
  cols;
  empTimesheetDetails: Array<any>;
  loader: boolean = false;
  source;
  constructor(private router: Router) {

   }

  ngOnInit() {
    this.cols = [
      { field: 'employee', header: 'Employee' },
      {field: 'position', header: 'Position' },
      { field: 'Has_Timesheet_Available', header: 'Has Timesheet Available' },
      { field: 'has_submitted_time', header: 'Has Submitted Time' },
      { field: 'has_been_approved', header: 'Has Been Approved' }
  ];
  
  this.cols_historical = [
    { field: 'employee', header: 'Employee' },
      {field: 'position', header: 'Position' },
      { field: 'Unapproved', header: '#Unapproved' },
      { field: 'Unsubmitted', header: '#Unsubmitted' }
];
this.cols_details = [
  { field: 'date', header: 'Dates' },
  {field: 'position', header: 'Position' },
  { field: 'Has_Timesheet_Available', header: 'Has Timesheet Available' },
  { field: 'Submitted', header: 'Submitted' },
  { field: 'has_been_approved', header: 'Has Been Approved' }
];
  this.empTimesheetDetails = [
    {employee: 'Employee-1',position:'Jr. Developer', Has_Timesheet_Available:'Yes', has_submitted_time: 'Yes', has_been_approved:'Yes'},
    {employee: 'Employee-2',position:'Developer', Has_Timesheet_Available:'No', has_submitted_time: 'Yes', has_been_approved:'Yes'},
    {employee: 'Employee-3',position:'Consultant', Has_Timesheet_Available:'Yes', has_submitted_time: 'Yes', has_been_approved:'Yes'},
    {employee: 'Employee-5',position:'Senior consultant', Has_Timesheet_Available:'Yes', has_submitted_time: 'Yes', has_been_approved:'Yes'},
    {employee: 'Employee-6',position:'Developer', Has_Timesheet_Available:'Yes', has_submitted_time: 'Yes', has_been_approved:'Yes'},
    {employee: 'Employee-7',position:'Developer', Has_Timesheet_Available:'Yes', has_submitted_time: 'No', has_been_approved:'Yes'},
    {employee: 'Employee-8',position:'Sr. Developer', Has_Timesheet_Available:'Yes', has_submitted_time: 'Yes', has_been_approved:'Yes'}
        
  ];
  this.historicalDetails = [
    {employee: 'Employee-1',position:'Jr. Developer', Unapproved:'3', Unsubmitted: '4'},
    {employee: 'Employee-2',position:'Developer', Unapproved:'2', Unsubmitted: '5'},
    {employee: 'Employee-3',position:'Consultant', Unapproved:'6', Unsubmitted: '2'},
    {employee: 'Employee-5',position:'Senior consultant', Unapproved:'3', Unsubmitted: '1'}
  ]
  this.emp_details_record = [
    {date: '23-09-2018',position:'Jr. Developer', Has_Timesheet_Available:'Yes', Submitted: 'Yes', has_been_approved:'Yes'},
    {date: '23-09-2018',position:'Developer', Has_Timesheet_Available:'No', Submitted: 'Yes', has_been_approved:'Yes'},
    {date: '13-07-2018',position:'Consultant', Has_Timesheet_Available:'Yes', Submitted: 'Yes', has_been_approved:'Yes'},
    {date: '23-09-2018',position:'Senior consultant', Has_Timesheet_Available:'Yes', Submitted: 'Yes', has_been_approved:'Yes'},
    {date: '23-09-2018',position:'Developer', Has_Timesheet_Available:'Yes', Submitted: 'Yes', has_been_approved:'Yes'},
    {date: '09-01-2018',position:'Developer', Has_Timesheet_Available:'Yes', Submitted: 'No', has_been_approved:'Yes'},
    {date: '20-07-2018',position:'Sr. Developer', Has_Timesheet_Available:'Yes', Submitted: 'Yes', has_been_approved:'Yes'}
        
  ];
  this.source = 'Approve';
  }
  showTimeSheetModal(index){
    this.timesheetData = true;
    // this.loader = true;
    
    // setTimeout(() => {
    //   this.loader = false;
    // this.timesheetData = true;
    // }, 1000);
  }
  showEmpDetails(index){
    this.detail_emp_div = false;
    this.loader = true;
    setTimeout(() => {
      this.loader = false;
      this.name_of_detail_emp = this.historicalDetails[index].employee;
      this.detail_emp_div = true;
    }, 1000);
  
  }
  hideDialog() {
    this.timesheetData = false;
  }
  goToEditTimesheet() {
    this.router.navigate(['/timekeeping/edit-timesheet']);
  }


}
