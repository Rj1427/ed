import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

//import { LoginRoutingModule } from './login-routing.module';
import { FormsModule } from '@angular/forms';
import { LoginComponent } from './login.component';
import {LoginService} from './login.service';
import { LoaderModule } from '../loader/loader.module';
import { MyMaterialModule } from '../material.module';

@NgModule({
  
  imports: [
    CommonModule,
   // LoginRoutingModule,
    FormsModule,
    LoaderModule,
    MyMaterialModule
    
  ],
  providers: [LoginService],
  declarations: [LoginComponent],
  exports: [LoginComponent]
})
export class LoginModule { }
