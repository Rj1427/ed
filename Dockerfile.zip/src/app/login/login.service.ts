import {Injectable} from '@angular/core';
import {HttpClient, HttpErrorResponse, HttpHeaders} from '@angular/common/http';
import {AuthPayload} from '../models/auth';
import {throwError} from 'rxjs';
import {catchError} from 'rxjs/operators';
import { debug } from 'util';

@Injectable()
export class LoginService {

  private httpOptions = {headers: new HttpHeaders({'Content-Type': 'application/json'})};
  private APIHost = 'http://api.businessopsdev.louisville.edu';
  // private APIHost = 'http://businessopsdev.louisville.edu:4200';
  private authURL = `${this.APIHost}/auth/api/v1/login`;
  private isloggedIn: boolean = false;
  constructor(private http: HttpClient) { }

  private static handleError(error: HttpErrorResponse) {
    if (error.error instanceof ErrorEvent) {
      // A client-side or network error occurred. Handle it accordingly.
      console.error('An error occurred:', error.error.message);
    } else {
      // The backend returned an unsuccessful response code.
      // The response body may contain clues as to what went wrong,
      // debugger;
      console.error(
        `Backend returned code ${error.status}, ` +
        `body was: ${error.error.message}`);
    }
    // return an observable with a user-facing error message
    return throwError(
      error.error.message);
  //  return error.error.message;
  }

  login(username: string, password: string) {
    return this.http.post<AuthPayload>(this.authURL, {username: username, password: password}, this.httpOptions).pipe(
      catchError(LoginService.handleError)
    );
  }
}
