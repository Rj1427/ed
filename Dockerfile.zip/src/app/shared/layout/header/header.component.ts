import { Component, OnInit, OnChanges } from '@angular/core';
import { Router, ActivatedRoute } from  '@angular/router';
import {AuthenticatedUserService} from '../../../services/authenticated-user';


@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
 showLogout = false;
  constructor(private auth: AuthenticatedUserService, private route: ActivatedRoute, private router: Router) {

  }
  ngOnInit() {
    this.router.events.subscribe((event) => {
      this.checkUserLoggedIn();
  });
  }
// By Shiva
  checkUserLoggedIn() {
    if (this.auth.checkLoggedIn()) {
      this.showLogout = true;
    }else{
      this.showLogout = false;
    }
  }
  logout() {
    this.showLogout = false;
    this.auth.logout();
  }
}
