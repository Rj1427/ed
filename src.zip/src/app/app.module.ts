import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';
import { AppRoutingModule } from './app-routing.module';
import { AngularFontAwesomeModule } from 'angular-font-awesome';
import { HttpClientModule} from '@angular/common/http';
import { AppComponent } from './app.component';
import { LoginModule } from './login/login.module';
import { HomeModule } from './home/home.module';
import { OnboardingModule } from './onboarding/onboarding.module';
import { TimekeepingModule } from './timekeeping/timekeeping.module';
import { LeaveModule } from './leave/leave.module';
import { TravelModule } from './travel/travel.module';
import { HelpModule } from './help/help.module';
import { LayoutModule } from './shared/layout/layout.module';
import { DashboardModule } from './dashboard/dashboard.module';
import { AuthGuard } from './guards/auth.guard';
import {AuthenticatedUserService} from './services/authenticated-user';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MyMaterialModule } from './material.module';
//import { routingComponents } from './app-routing.module';

// import { OnboardingApplicantModule } from './onboarding-applicant/onboarding-applicant.module';



@NgModule({
  declarations: [
    AppComponent
    //...routingComponents
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    LoginModule,
    HomeModule,
    OnboardingModule,
    TimekeepingModule,
    LeaveModule,
    TravelModule,
    HelpModule,
    LayoutModule,
    AngularFontAwesomeModule,
    NgbModule.forRoot(),
    DashboardModule,
    BrowserAnimationsModule,
    MyMaterialModule
    // OnboardingApplicantModule


  ],
  //exports:[LoaderComponent],
  providers: [AuthGuard, AuthenticatedUserService],
  bootstrap: [AppComponent]
})
export class AppModule { }
