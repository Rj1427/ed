import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-timekeeping',
  templateUrl: './timekeeping.component.html',
  styleUrls: ['./timekeeping.component.css']
})
export class TimekeepingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
