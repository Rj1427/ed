import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-timesheet',
  templateUrl: './edit-timesheet.component.html',
  styleUrls: ['./edit-timesheet.component.css']
})
export class EditTimesheetComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
