import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-timesheet-print-view',
  templateUrl: './timesheet-print-view.component.html',
  styleUrls: ['./timesheet-print-view.component.css']
})
export class TimesheetPrintViewComponent implements OnInit {
  source: string;
  constructor() { }

  ngOnInit() {
    this.source = "printView";
  }

}
