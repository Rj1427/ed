import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TimesheetPrintViewComponent } from './timesheet-print-view.component';

describe('TimesheetPrintViewComponent', () => {
  let component: TimesheetPrintViewComponent;
  let fixture: ComponentFixture<TimesheetPrintViewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TimesheetPrintViewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TimesheetPrintViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
