import { AuthenticatedUserService } from './../services/authenticated-user';
import { Injectable } from '@angular/core';
import { Router, CanActivate, CanActivateChild, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs';



@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate, CanActivateChild {
  constructor(private authenticatedUserService: AuthenticatedUserService, private router: Router){}
  // By Shiva
  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
    if(this.authenticatedUserService.checkLoggedIn()) {
      return true;
    }else{
      this.authenticatedUserService.logout();
      return false;
    }
  }
  canActivateChild(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
  let userRole = this.authenticatedUserService.getUserRole().includes('depthire');
    if(this.authenticatedUserService.checkLoggedIn() && userRole){
      return true;
    }else{
      this.authenticatedUserService.logout();
      return false;
    }
 
  }
}
