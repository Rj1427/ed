import { Request } from '@angular/http';
import { Component, OnInit, ViewChild } from '@angular/core';
//import { ApplicantModel } from "./applicant-modal";
import { DashboardService } from "./dashboard.service";
import { DatePipe } from '@angular/common';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormControl
} from '@angular/forms';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  editForm: FormGroup;
  applicants: Array<any> = [];
  cols;
  showLoader: boolean = false;
  topLoader: boolean = false;
  taskData: boolean = false;
  taskInstructions: boolean = false;
  ticketDataDetails = '';
  showTicketData: boolean = false;
  displayCancelTicketModal: boolean = false;
  isCompelete: boolean = false;
  @ViewChild('message') message;
  businessOperations;
  i9Verification;
  readyToSchedule;
  dataCommittedPeopleSoft;
  displayView: boolean = false;
  displayEdit: boolean = false;
  rowSelected: boolean = false;
  disableTicketDetailBtn: boolean = true;
  instructionsMessage: string = '';
  allInstructionsMessage: Array<any> = [];
  EmploymentTypes;
  allTicketData = [];
  allWorkflow = [];
  workflow = [];
  
  // fundSourceDetails = [];
  constructor(private formBuilder: FormBuilder, private dashboardService: DashboardService, private datePipe: DatePipe) { }
  ngOnInit() {
    this.editForm = this.formBuilder.group({

      employment_type: new FormControl('', [        
        Validators.required
      ]),
      cbc_funding_source: new FormControl('', [        
        Validators.required
      ]),
      pay_rate: new FormControl('', [        
        Validators.required
      ]),
      hours_per_week: new FormControl('', [        
        Validators.required
      ]),
      department_name: new FormControl('', [        
        Validators.required
      ]),
      start_date: new FormControl('', [        
        Validators.required
      ]),
      end_date: new FormControl('', [        
        Validators.required
      ]),
      position_number: new FormControl('', [        
        Validators.required
      ]),
      speedtype: new FormControl('', [        
        Validators.required
      ]),
      percentage: new FormControl('', [    
        Validators.required
      ])
    });
//Fetch ticket details
      this.dashboardService.getTicket().subscribe(res=>{
        this.allTicketData = (res as any).tickets;
        let tickets = this.allTicketData;
        let applicat_Full_name, dept_Full_name;
        for(let i=0; i < tickets.length; i++){
          applicat_Full_name = tickets[i].request_data.first_name+" "+tickets[i].request_data.middle_name+" "+tickets[i].request_data.last_name;
          dept_Full_name = tickets[i].request_data.department_number+"-"+tickets[i].request_data.department_name;  
          tickets[i].request_data.applicat_Full_name = applicat_Full_name;
          tickets[i].request_data.dept_Full_name = dept_Full_name;
          tickets[i].request_data.status = tickets[i].status;
          tickets[i].request_data.submitter = tickets[i].submitter;
          tickets[i].request_data.submitted_timestamp = this.transformDate(tickets[i].submitted_timestamp);
          tickets[i].request_data.request_id = tickets[i].request_id;
          tickets[i].request_data.start_date = this.transformDate(tickets[i].request_data.start_date);
          this.applicants.push(tickets[i].request_data);
          this.allWorkflow.push(tickets[i].workflow.states);
        }
      }        
    );

//Set table header
    this.cols = [
      { field: 'status', header: 'Status' },
      {field: 'employment_type', header: 'Type' },
      { field: 'applicat_Full_name', header: 'Applicant' },
      { field: 'submitter', header: 'Employee ID' },


      { field: 'start_date', header: 'Hire Date' },
      {field: 'dept_Full_name', header: 'Department' },
      { field: 'submitted_timestamp', header: 'Submitted' },
      { field: 'position_number', header: 'Position#' },

      {field: 'NA', header: 'CBC Checked' },
      { field: 'NA', header: 'CBC Received' },
      { field: 'NA', header: 'Current Step' }
  ];
    // this.businessOperations = [
    //   {"name":"Validate Position","status": "Not completed"},
    //   {"name":"Validate Applicant Hours","status": "Not completed"},
    //   {"name":"Validate Need for CBC","status": "Not completed"},
    //   {"name": "CBC Completed", "status": "Not completed"}
    // ];

    // this.i9Verification  = [
    //   {"name":"Validate Need for CBC","status": "Not completed"},     
    // ];
    // this.readyToSchedule   = [
    //   {"name":"Send Ready to Schedule email","status": "Not completed"}    
    // ];
    // this.dataCommittedPeopleSoft = [

    //   {"name":"Enter data into PeopleSoft","status": "Not completed"}

    // ]
    this.EmploymentTypes = [
        {"value": "student", "text":"student"},
        {"value": "federal", "text":"Federal Work Study"},
        {"value": "graduate", "text":"Graduate assistant"},
        {"value": "monthly", "text":"Hourly Temporary"},
        {"value": "hourly", "text":"Monthly Temporary"}
    ]
  }
    transformDate(date) {
      return this.datePipe.transform(date,"M/d/yy, h:mm a");
    }
  showDetails(index){
    this.disableTicketDetailBtn = true;
    this.rowSelected = true;
    this.taskData = false;
    this.showLoader = true;
    this.showTicketData = false;
    this.taskInstructions = false;
    this.ticketDataDetails = this.applicants[index];
    this.workflow = this.allWorkflow[index];
    setTimeout(() => {
        this.showLoader = false;
        this.taskData = true; 
        this.disableTicketDetailBtn = false;
        this.showTicketData = true;
        this.taskInstructions = true;
      }, 1000);
  }
  markAsCompelete(tab, row){
    if(tab == 'businessOperations')
      this.businessOperations[row].status = 'Completed';
    else if(tab == 'i9Verification')
      this.i9Verification[row].status = 'Completed';
    else if(tab == 'readyToSchedule')
      this.readyToSchedule[row].status = 'Completed';
    else if(tab == 'dataCommittedPeopleSoft')
      this.dataCommittedPeopleSoft[row].status = 'completed';
  }
  setInstructionsMessage(event){
    this.instructionsMessage = event.target.value;
  }
  postMessage(){
    this.allInstructionsMessage.push({"dateTime":new Date(), "message": this.instructionsMessage});
   this.message.nativeElement.innerHTML =  '';
  }
  showTicketDetail() {
    if(this.rowSelected)
      this.displayView = true;
    else
      this.disableTicketDetailBtn = false;

  }
  saveData(edited){
    this.topLoader = true;
    (this.ticketDataDetails as any).employment_type = edited.value.employment_type;
    (this.ticketDataDetails as any).cbc_funding_source = edited.value.cbc_funding_source;
    (this.ticketDataDetails as any).pay_rate = edited.value.pay_rate;
    (this.ticketDataDetails as any).hours_per_week = edited.value.hours_per_week;
    (this.ticketDataDetails as any).department_name = edited.value.department_name;
    //edited.value.start_date.year+'-'+edited.value.start_date.month+'-'+edited.value.start_date.day;
    
     (this.ticketDataDetails as any).start_date = new Date(edited.value.start_date.year, edited.value.start_date.month,edited.value.start_date.day).toISOString();
   //edited.value.end_date.year+'-'+edited.value.end_date.month+'-'+edited.value.end_date.day;
    (this.ticketDataDetails as any).end_date = new Date(edited.value.end_date.year, edited.value.end_date.month,edited.value.end_date.day).toISOString();
    (this.ticketDataDetails as any).position_number = edited.value.position_number;
    (this.ticketDataDetails as any).position_funding_sources = [{
      "speedtype" : edited.value.speedtype,
      "percentage" : edited.value.percentage
    }];
    let upadated_val = {
      cbc_funding_source: (this.ticketDataDetails as any).cbc_funding_source,
      comment: (this.ticketDataDetails as any).comment,
      created_on: (this.ticketDataDetails as any).created_on,
      department_name: (this.ticketDataDetails as any).department_name,
      department_number: (this.ticketDataDetails as any).department_number,
      email_address: (this.ticketDataDetails as any).email_address,
      employee_id: (this.ticketDataDetails as any).employee_id,
      employment_type: (this.ticketDataDetails as any).employment_type,
      etag: "2c63a77fd87c1749b65214d853a6a17a998631bf44a4b702bf7c1430defde748",
      first_name: (this.ticketDataDetails as any).first_name,
      graduate_position_type: (this.ticketDataDetails as any).graduate_position_type,
      hours_per_week: (this.ticketDataDetails as any).hours_per_week,
      last_modified: (this.ticketDataDetails as any).last_modified,
      last_name: (this.ticketDataDetails as any).last_name,
      middle_name: (this.ticketDataDetails as any).middle_name,
      pay_period: (this.ticketDataDetails as any).pay_period,
      pay_rate: (this.ticketDataDetails as any).pay_rate,
      position_funding_sources: [
      {
        percentage: (this.ticketDataDetails as any).position_funding_sources[0].percentage,
        speedtype: (this.ticketDataDetails as any).position_funding_sources[0]. speedtype
      }
      ],
      position_number: (this.ticketDataDetails as any).position_number,
      request_id: (this.ticketDataDetails as any).request_id,
      start_date: (this.ticketDataDetails as any).start_date,
      supervisor: (this.ticketDataDetails as any).supervisor,
      supervisor_email: (this.ticketDataDetails as any).supervisor_email,
      wsan_award: (this.ticketDataDetails as any).wsan_award
      }
    this.dashboardService.updateTicket(upadated_val).subscribe(res=>{
      this.displayEdit = false;
      this.topLoader = false;
    });
  }
  cancelTicket(){
    this.displayCancelTicketModal = true;
  }
  editTicketDetail(){
    if(this.ticketDataDetails){
      
      this.editForm.patchValue({
        employment_type: (this.ticketDataDetails as any).employment_type,
        cbc_funding_source: (this.ticketDataDetails as any).cbc_funding_source,
        pay_rate: (this.ticketDataDetails as any).pay_rate,
        hours_per_week: (this.ticketDataDetails as any).hours_per_week,
        department_name: (this.ticketDataDetails as any).department_name,       
        start_date: this.ngbDate((this.ticketDataDetails as any).start_date),
        end_date: this.ngbDate((this.ticketDataDetails as any).end_date),
        position_number: (this.ticketDataDetails as any).position_number,
        speedtype: (this.ticketDataDetails as any).position_funding_sources[0].speedtype,              
        percentage: (this.ticketDataDetails as any).position_funding_sources[0].percentage 
      });
    }
  
    this.displayEdit = true;
  }
  addNewFundingSource() {

    (this.ticketDataDetails as any).PositionFunding.push({speedtype: '', percentage: ''});
    //window.scrollTo(0,document.body.scrollHeight);
   
  }
  removeFundingSource(i) {
    (this.ticketDataDetails as any).PositionFunding.splice(i,1);
  }
  ngbDate(fullDate){
    let formatedDate = {
      day: new Date(fullDate).getDate(),
      month: new Date(fullDate).getDay(),
      year:new Date(fullDate).getFullYear()
  }
  return formatedDate;
}
  hideDialog(view){
    if(view == 'edit') {
      this.displayEdit = false;
    }else if(view == 'cancelTicket'){
      this.displayCancelTicketModal = false;
    }   
    else
      this.displayView = false;
  }
 
}
