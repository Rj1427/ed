import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
//import { BrowserAnimationsModule, NoopAnimationsModule  } from '@angular/platform-browser/animations';
import { DashboardComponent } from './dashboard.component';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { AngularFontAwesomeModule } from 'angular-font-awesome';
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';
import {TableModule} from 'primeng/table';
import {AccordionModule} from 'primeng/accordion';
import {DialogModule} from 'primeng/dialog';
import { DashboardService } from './dashboard.service';
import { DatePipe } from '@angular/common';
import { LoaderModule } from '../loader/loader.module';

const routes: Routes = [
  {
    path: '',
    component: DashboardComponent
  }
];

@NgModule({
  imports: [
    CommonModule,
 //   BrowserAnimationsModule,
 //   NoopAnimationsModule,
    AngularFontAwesomeModule,
    TableModule,
    AccordionModule,
    DialogModule,
    NgbModule,
    FormsModule,
    ReactiveFormsModule,
    LoaderModule,
    RouterModule.forChild(routes)
   // CalendarModule
   
  ],
  providers: [DashboardService, DatePipe],
  declarations: [DashboardComponent],
  exports: [DashboardComponent]
})
export class DashboardModule { }
