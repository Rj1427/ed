import * as moment from 'moment';

interface AddressJSON {
  street_line_1: string;
  street_line_2: string;
  city: string;
  state: string;
  zip_code: string;
}

interface PositionJSON {
  employee_record: number;
  job_title: string;
  position_number: string;
  standard_hours: number;
  fte: number;
  department_name: string;
  department_number: string;
  supervisor_id: string;
  supervisor_name: string;
}

interface EmployeeJSON {
  user_id: string;
  employee_id: string;
  first_name: string;
  middle_name: string;
  last_name: string;
  email_address: string;
  birthdate: string;
  addresses: { home: AddressJSON, mail: AddressJSON };
  positions: PositionJSON[];
  supervises: string[];
  timekeeper_departments: string[];
}

export class Employee {
  user_id: string;
  employee_id: string;
  first_name: string;
  middle_name: string;
  last_name: string;
  email_address: string;
  birthdate: moment.Moment;
  addresses: { home: AddressJSON, mail: AddressJSON };
  positions: PositionJSON[];
  supervises: string[];
  timekeeper_departments: string[];

  static fromJSON(json: EmployeeJSON|string): Employee {
    if (typeof json === 'string') {
      return JSON.parse(json, Employee.reviver);
    } else {
      const employee = Object.create(Employee.prototype);
      return Object.assign(employee, json, {
        birthdate: moment(json.birthdate)
      });
    }
  }

  static reviver(key: string, value: any): any {
    return key === '' ? Employee.fromJSON(value) : value;
  }
}
