import { Component, OnInit, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-direct-deposit',
  templateUrl: './direct-deposit.component.html',
  styleUrls: ['./direct-deposit.component.css']
})
export class DirectDepositComponent implements OnInit {
  @Output() tabindex: EventEmitter<any> = new EventEmitter<any>();
  pay_type_choice: string = "plastic_pay";
  constructor() { }

  ngOnInit() {
  }
  goToPrev(tab: any): void {
    this.tabindex.emit(tab);
  }
  goToNext(tab: any): void {
   //if (this.form.valid) {
    this.tabindex.emit(tab);
   //} else {
     //this.validateAllFormFields(this.form); 
  //}
   }
}
