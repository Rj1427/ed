import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DisabilityStatusComponent } from './disability-status.component';

describe('DisabilityStatusComponent', () => {
  let component: DisabilityStatusComponent;
  let fixture: ComponentFixture<DisabilityStatusComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DisabilityStatusComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DisabilityStatusComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
