import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GenderEthnicityComponent } from './gender-ethnicity.component';

describe('GenderEthnicityComponent', () => {
  let component: GenderEthnicityComponent;
  let fixture: ComponentFixture<GenderEthnicityComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GenderEthnicityComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GenderEthnicityComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
