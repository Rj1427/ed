import { Component, OnInit, EventEmitter, Output } from '@angular/core';
@Component({
  selector: 'app-appointment-agreement',
  templateUrl: './appointment-agreement.component.html',
  styleUrls: ['./appointment-agreement.component.css']
})
export class AppointmentAgreementComponent implements OnInit {
  @Output() tabindex: EventEmitter<any> = new EventEmitter<any>();
  authorized_use_agreement_1 = false;
  authorized_use_agreement_2 = false;
  authorized_use_agreement_3 = false;
  authorized_use_agreement_4 = false;
  authorized_use_agreement_5 = false;
  authorized_use_agreement_6 = false;
    
  constructor() { }

  ngOnInit() {
  }
  goToPrev(tab: any): void {
    this.tabindex.emit(tab);
  }
  finish(tab: any): void {
    if(this.authorized_use_agreement_1 && this.authorized_use_agreement_2 && this.authorized_use_agreement_3 && this.authorized_use_agreement_4 && this.authorized_use_agreement_5 && this.authorized_use_agreement_6)
      alert("Thanks for submiting the details!!");
    else
    alert("Please choose all terms and condition!!");
 }
}
