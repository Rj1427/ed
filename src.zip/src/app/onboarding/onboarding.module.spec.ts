import { OnboardingModule } from './onboarding.module';

describe('OnboardingModule', () => {
  let onboardingModule: OnboardingModule;

  beforeEach(() => {
    onboardingModule = new OnboardingModule();
  });

  it('should create an instance', () => {
    expect(onboardingModule).toBeTruthy();
  });
});
