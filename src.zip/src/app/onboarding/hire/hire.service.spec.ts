import { TestBed, inject } from '@angular/core/testing';

import { HireService } from './hire.service';

describe('HireService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [HireService]
    });
  });

  it('should be created', inject([HireService], (service: HireService) => {
    expect(service).toBeTruthy();
  }));
});
