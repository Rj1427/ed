import { Router } from '@angular/router';
import { Component, OnInit, EventEmitter, Output, Input } from '@angular/core';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormControl
} from '@angular/forms';
import { HireService } from '../hire.service';

@Component({
  selector: 'app-funding',
  templateUrl: './funding.component.new.html',
  styleUrls: ['./funding.component.scss']
})
export class FundingComponent implements OnInit {
  form: FormGroup;
  position_funding_sources = [{ speedtype: '', percentage: '' }];
  position_cur_index: number = this.position_funding_sources.length;
  @Output() tabindex: EventEmitter<any> = new EventEmitter<any>();
  @Input() step;
  candidate: any;
  constructor(private router: Router, private formBuilder: FormBuilder, private hireService: HireService) { }

  ngOnInit() {
    this.candidate = this.hireService.candidateDetails;
    this.form = this.formBuilder.group({
      criminal_bg_chk: [this.candidate.criminal_bg_chk, Validators.required],
      speedtype: this.candidate.speedtype,
      percentage: this.candidate.percentage,
    });
  }
  prevStep(tab: any): void {
    this.step = tab;
    this.tabindex.emit({ tab: tab, isPrev: true });
  }
  nextStep(tab: any): void {
    if (this.form.valid) {
      if (this.form.value.percentage !== 100) {
        alert('Position Funding must add up to 100%');
      } else {
        let sendToParent = { tab: tab, formVal: this.form.value };
        this.tabindex.emit(sendToParent);
      }

    } else {
      this.validateAllFormFields(this.form);
    }
  }


  addFundingSource() {
    // console.log(`speedtype${this.position_cur_index}`);
    // this.form.addControl(`speedtype${this.position_cur_index}`, null );
    // this.form.addControl(`percentage${this.position_cur_index}`, null );

    this.position_funding_sources.push({ speedtype: '', percentage: '' });
    //this.position_cur_index++;
  }
  removeFundingSource(i) {
    // console.log(i)
    this.position_funding_sources.splice(i, 1);
  }

  validateAllFormFields(formGroup: FormGroup) {
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field);
      if (control instanceof FormControl) {
        control.markAsTouched({ onlySelf: true });
        return false;
      } else if (control instanceof FormGroup) {
        this.validateAllFormFields(control);
      }
    });
  }
}
