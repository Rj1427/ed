import { HireService } from './../hire.service';
import { Router } from '@angular/router';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormControl,
  FormGroupDirective,
  NgForm
} from '@angular/forms';
import { Component, OnInit, EventEmitter, Output, Input } from '@angular/core';
import { MatTabsModule } from '@angular/material';
import { ErrorStateMatcher } from '@angular/material/core';

/** Error when invalid control is dirty, touched, or submitted. */
export class MyErrorStateMatcher implements ErrorStateMatcher {
  isErrorState(control: FormControl | null, form: FormGroupDirective | NgForm | null): boolean {
    const isSubmitted = form && form.submitted;
    return !!(control && control.invalid && (control.dirty || control.touched || isSubmitted));
  }
}

@Component({
  selector: 'app-candidate',
  templateUrl: './candidate.component.html',
  styleUrls: ['./candidate.component.scss']
})
export class CandidateComponent implements OnInit {
  @Output() tabindex: EventEmitter<any> = new EventEmitter<any>();
  @Input() step;
  form: FormGroup;

  matcher = new MyErrorStateMatcher();
  constructor(private router: Router, private formBuilder: FormBuilder, private hireService: HireService) { }

  ngOnInit() {
    const candidateDetails = this.hireService.candidateDetails;
    this.form = this.formBuilder.group({
      employee_id: candidateDetails.employee_id,
      first_name: [candidateDetails.first_name, Validators.required],
      middle_name: candidateDetails.middle_name,
      last_name: [candidateDetails.last_name, Validators.required],
      email_address: [candidateDetails.email_address, [Validators.required, Validators.email]],
    });
  }

  isFieldValid(field: string) {
    return !this.form.get(field).valid && this.form.get(field).touched;
  }

  displayFieldCss(field: string) {
    return {
      'has-error': this.isFieldValid(field),
      'has-feedback': this.isFieldValid(field)
    };
  }

  validateAllFormFields(formGroup: FormGroup) {
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field);
      if (control instanceof FormControl) {
        control.markAsTouched({ onlySelf: true });
        return false;
      } else if (control instanceof FormGroup) {
        this.validateAllFormFields(control);
      }
    });
  }

  nextStep(tab: number) {
    if (this.form.valid) {
      this.step++;
      const sendToParent = { tab: tab, formVal: this.form.value };
      this.tabindex.emit(sendToParent);
    } else {
      this.validateAllFormFields(this.form);
    }

  }

  // prevStep() {
  //   this.step--;
  // }

}
