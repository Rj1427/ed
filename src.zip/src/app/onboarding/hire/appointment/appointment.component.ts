import { Component, OnInit, EventEmitter, Output, Input } from '@angular/core';
import { Router } from '@angular/router';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormControl
} from '@angular/forms';
import { HireService } from '../hire.service';

@Component({
  selector: 'app-appointment',
  templateUrl: './appointment.component.new.html',
  styleUrls: ['./appointment.component.scss']
})
export class AppointmentComponent implements OnInit {
  @Output() tabindex: EventEmitter<any> = new EventEmitter<any>();
  @Input() step;
  form: FormGroup;
  Start_date: any = '';
  end_date: any = '';
  displayMonths = 3;
  candidate: any;
  constructor(private router: Router, private formBuilder: FormBuilder, private hireService: HireService) { }

  ngOnInit() {
    this.candidate = this.hireService.candidateDetails;
    this.form = this.formBuilder.group({
      app_start_date: [this.candidate.Start_date, Validators.required],
      //app_end_date: [null, Validators.required],
      app_end_date: this.candidate.end_date
    });
  }
  onDateSelect(event) {
    if (this.Start_date != '' && this.end_date != '') {
      var d1 = this.Start_date;
      var d2 = this.end_date;
      if (d1.year > d2.year) {
        alert("Date range error!");
        this.end_date = '';
      } else if (d1.month > d2.month) {
        alert("Date range error!");
        this.end_date = '';
      } else if (d1.day > d2.day) {
        alert("Date range error!");
        this.end_date = '';
      }
    }
  }

  prevStep(tab: any): void {
    this.step = tab;
    this.tabindex.emit({ tab: tab, isPrev: true });
  }
  nextStep(tab: any): void {
    if (this.form.valid) {
      console.log(this.form.value);
      let sendToParent = { tab: tab, formVal: this.form.value };
      this.tabindex.emit(sendToParent);
    } else {
      this.validateAllFormFields(this.form);
    }
  }
  validateAllFormFields(formGroup: FormGroup) {
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field);
      if (control instanceof FormControl) {
        control.markAsTouched({ onlySelf: true });
        return false;
      } else if (control instanceof FormGroup) {
        this.validateAllFormFields(control);
      }
    });
  }
}
