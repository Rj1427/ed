import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { LeaveRoutingModule } from './leave-routing.module';
import { LeaveComponent } from './leave.component';

@NgModule({
  imports: [
    CommonModule,
    LeaveRoutingModule
  ],
  declarations: [LeaveComponent],
  exports: [LeaveComponent]
})
export class LeaveModule { }
