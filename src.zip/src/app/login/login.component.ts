import { Component, OnInit } from '@angular/core';
import { LoginService } from './login.service';
import { Router} from '@angular/router';
import {AuthenticatedUserService} from '../services/authenticated-user';
//import { LoaderComponent } from '../loader/loader.component';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  errMsg: string;
  error: boolean = false;
  showLoader: boolean = false;
  hide = true;
  constructor(
    private router: Router,
    private loginService: LoginService,
    private authenticatedUserService: AuthenticatedUserService
  ) {}

ngOnInit() {}

  onSubmit(user) {
  //   this.showLoader = true;
  //   this.loginService.login(user.username, user.password)
  //     .subscribe(payload => {
  //       this.authenticatedUserService.processLogin(payload);
  //       this.showLoader = false;
  //       this.router.navigate(['/home']);
  //     }, err => {
  //       this.errMsg = err;
  //       this.error = true;
  //       this.showLoader = false;});
  // }
  this.router.navigate(['/home']);
  }
}
