import { TravelModule } from './travel.module';

describe('TravelModule', () => {
  let travelModule: TravelModule;

  beforeEach(() => {
    travelModule = new TravelModule();
  });

  it('should create an instance', () => {
    expect(travelModule).toBeTruthy();
  });
});
