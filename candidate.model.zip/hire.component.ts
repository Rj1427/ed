import { MatDatepickerInputEvent } from '@angular/material';
import { CandidateDetails } from './candidate.model';
import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { HireService } from './hire.service';
import { Router } from '@angular/router';
import { FormGroup, Validators, FormBuilder, FormControl } from '@angular/forms';
@Component({
  selector: 'app-hire',
  templateUrl: './hire.component.html',
  styleUrls: ['./hire.component.scss']
})
export class HireComponent implements OnInit {
  tabToDisplay = 1;
  step = 1;
  isDisabled = true;
  form: FormGroup;
  position_funding_sources = [{ speedtype: '', percentage: '' }];
  position_cur_index: number = this.position_funding_sources.length;
  candidate_hire__details: CandidateDetails;
  today = new Date();
  graduate_position_val: string;
  display_graduate_sec = false;
  start_date: any = '';
  end_date: any = '';
  isEndDateDisable = true;
  errorMessage = '';

  hiring_department = [
    { key: '1010000156', name: '1010000156 - Office of the President' },
    { key: '1010000184', name: '1010000184 -  Office of the President-GIE' },
    { key: '1011000156', name: '1010000156 -  Admin Supp Serv-Stu Serv' },
    { key: '1017000156', name: '1017000156 - Boards - Institutional Support' },
    { key: '1018000144', name: '1018000144 - Commissions' },
    {
      key: '1013000156',
      name: '1013000156 - Office of Communication &amp; Mktg'
    }
  ];
  employment_Types = [
    { key: 'student', name: 'Student' },
    { key: 'federal', name: 'Federal Work Study' },
    { key: 'graduate', name: 'Graduate Assistant' },
    { key: 'hourly', name: 'Hourly Temporary' },
    { key: 'monthly', name: 'Monthly Temporary' },
    { key: 'lecturer-11', name: 'L11 Lecturer' },
    { key: 'lecturer-12', name: 'L12 Lecturer' },
    { key: 'house-h12', name: 'House Staff' }
  ];

  payPeriods = [
    { key: 'Hourly', name: 'Hourly' },
    { key: 'Monthly', name: 'Monthly' }
  ];

  graduate_positions = [
    { key: 'GF', name: 'Graduate Fellow' },
    { key: 'GTA', name: 'Graduate Teaching Assistant' },
    { key: 'GRA', name: 'Graduate Research Assistant' },
    { key: 'GSA', name: 'Graduate Service Assistant' }
  ];
  constructor(
    private router: Router,
    private hireService: HireService,
    private changeDetectorRef: ChangeDetectorRef,
    private formBuilder: FormBuilder
  ) {}

  ngOnInit() {
    this.form = this.formBuilder.group({
      employee_id: '',
      first_name: ['', Validators.required],
      middle_name: '',
      last_name: ['', Validators.required],
      email_address: ['', [Validators.required, Validators.email]],
      employment_type: ['', Validators.required],
      position_number: '',
      hiring_department: ['', Validators.required],
      graduate_position_type: '',
      pay_rate: ['', [Validators.required,Validators.min(0)]],
      pay_period: ['', Validators.required],
      hours_per_week: ['', Validators.required],
      criminal_bg_chk: ['', Validators.required],
      speedtype: '',
      percentage: ['', Validators.min(2)],
      app_start_date: ['', Validators.required],
      app_end_date: '',
      supervisor_name: ['', Validators.required],
      supervisor_email: ['', [Validators.required, Validators.email]],
      comment: ''
    });
  }
  tabOnClick(e) {
    this.tabToDisplay = e;
    window.scrollTo(0, 0);
  }
  prevStep(tab: any): void {
    this.step = tab;
    const page = { tab: tab, isPrev: true };
    this.tabToShow(page);
  }
  nextStep(tab: any): void {
    this.step = tab;
    const page = { tab: tab, isPrev: false };
    this.tabToShow(page);
  }
  addFundingSource() {
    this.position_funding_sources.push({ speedtype: '', percentage: '' });
  }
  removeFundingSource(i) {
    this.position_funding_sources.splice(i, 1);
  }
  addEvent(type: string, event: MatDatepickerInputEvent<Date>) {
    this.isEndDateDisable = false;
    this.start_date = event.value;
  }
  validateAllFormFields(formGroup: FormGroup) {
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field);
      if (control instanceof FormControl) {
        control.markAsTouched({ onlySelf: true });
        return false;
      } else if (control instanceof FormGroup) {
        this.validateAllFormFields(control);
      }
    });
  }
  public tabToShow(e) {
    if (!e.isPrev) {
      if (e.tab == 2) {
        this.candidate_hire__details.created_on = this.today.toISOString();
        this.candidate_hire__details.last_modified = this.today.toISOString();
        this.candidate_hire__details.employee_id = e.formVal.employee_id;
        this.candidate_hire__details.first_name = e.formVal.first_name;
        this.candidate_hire__details.middle_name = e.formVal.middle_name;
        this.candidate_hire__details.last_name = e.formVal.first_name;
        this.candidate_hire__details.email_address = e.formVal.email_address;
      } else if (e.tab == 3) {
        this.candidate_hire__details.employment_type =
          e.formVal.employment_type;
        this.candidate_hire__details.graduate_position_type =
          e.formVal.graduate_position_type;
        this.candidate_hire__details.position_number =
          e.formVal.position_number;

        this.candidate_hire__details.department_number =
          e.formVal.hiring_department;
        this.candidate_hire__details.department_name = e.formVal.hireDepName;

        this.candidate_hire__details.pay_rate = e.formVal.pay_rate;
        this.candidate_hire__details.pay_period = e.formVal.pay_period;
        this.candidate_hire__details.hours_per_week = e.formVal.hours_per_week;
      } else if (e.tab == 4) {
        this.candidate_hire__details.position_funding_sources = [
          {
            speedtype: e.formVal.speedtype,
            percentage: e.formVal.percentage
          }
        ];
        this.candidate_hire__details.cbc_funding_source =
          e.formVal.criminal_bg_chk;
      } else if (e.tab == 5) {
        this.candidate_hire__details.start_date = e.formVal.app_start_date
          .toISOString()
          .substring(0, 10);
        this.candidate_hire__details.end_date = e.formVal.app_end_date
          .toISOString()
          .substring(0, 10);
      } else if (e.tab == 6) {
        this.candidate_hire__details.supervisor = e.formVal.supervisor_name;
        this.candidate_hire__details.supervisor_email =
          e.formVal.supervisor_email;
        this.candidate_hire__details.comment = e.formVal.comment;
        // call service
        this.hireService
          .setOnboardingHire(this.candidate_hire__details)
          .subscribe(res => {
            this.router.navigate(['/home', { success: true }]);
          });
      }
    }
    this.changeDetectorRef.detectChanges();
    window.scrollTo(0, 0);
  }
  displayFieldCss(field: string) {
    return {
      'has-error': this.isFieldValid(field),
      'has-feedback': this.isFieldValid(field)
    };
  }

  isFieldValid(field: string) {
    // console.log(!this.form.get(field).valid && this.form.get(field).touched);
    return !this.form.get(field).valid && this.form.get(field).touched;
  }
  finishStep(tab) {
    if (this.form.valid) {
      const sendToParent = { tab: tab, formVal: this.form.value };
      this.tabToShow(sendToParent);
    } else {
      this.validateAllFormFields(this.form);
      this.errorMessage = 'Please submit all details';
      setTimeout(() => {
        this.errorMessage = '';
        this.changeDetectorRef.detectChanges();
      }, 2000);
    }
  }
  hide() {
    this.errorMessage = '';
  }
  showAdditionalInfo(event) {
    this.graduate_position_val = event.target.value;
  }
  employment(event) {
    if (event.value == 'graduate') {
      this.display_graduate_sec = true;
    } else {
      this.display_graduate_sec = false;
    }
  }
  private getHireDeptName(id) {
    let len = this.hiring_department.length;
    for (let i = 0; i < len; i++) {
      if (this.hiring_department[i].key == id) {
        return this.hiring_department[i].name;
      }
    }
  }
  radioValue(event){
    this.graduate_position_val = event.value;
  }
  
}
