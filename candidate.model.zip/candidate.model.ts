export class CandidateDetails {
  created_on: String;
  last_modified: String;
  etag: 'ffdbb62e16aadb9c8478b41b2485433e67775c7b4c6c45da3acb3f098d55f88c';
  employee_id: String;
  first_name: String;
  middle_name: String;
  last_name: String;
  email_address: String;
  employment_type: String;
  start_date: String;
  pay_period: String;
  pay_rate: String;
  position_number: String;
  department_number: String;
  department_name: String;
  position_funding_sources: [
    {
      speedtype: String;
      percentage: String;
    }
  ];
  hours_per_week: String;
  graduate_position_type: String;
  cbc_funding_source: String;
  comment: String;
  wsan_award: String;
  supervisor: String;
  supervisor_email: String;
  cbc_needed: true;
  end_date: String;
}
