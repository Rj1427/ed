import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {ModuleWithProviders} from '@angular/core';
import { CandidateComponent } from './hire/candidate/candidate.component';
import { JobComponent } from './hire/job/job.component';
import { FundingComponent } from './hire/funding/funding.component';
import { AppointmentComponent } from './hire/appointment/appointment.component';
import { AdministrativeComponent } from './hire/administrative/administrative.component';
const onboardingRoutes: Routes = [
  
      {
        path: '',
        component: CandidateComponent
      },
      {
        path: 'candidate',
        component: CandidateComponent
      },
      {
        path: 'job',
        component: JobComponent
      },
      {
        path: 'funding',
        component: FundingComponent
      },
      {
        path: 'appointment',
        component: AppointmentComponent
      },
      {
        path: 'administrative',
        component: AdministrativeComponent
      }

];
//export const onboardingRouting: ModuleWithProviders = RouterModule.forChild(onboardingRoutes);
@NgModule({
  imports: [RouterModule.forChild(onboardingRoutes)],
  exports: [RouterModule]
})
export class OnboardingRoutingModule { }
export const onboardingComponents = [AdministrativeComponent, AppointmentComponent, FundingComponent, JobComponent, CandidateComponent];