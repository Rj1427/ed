import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';
import { AngularFontAwesomeModule } from 'angular-font-awesome';
import { OnboardingRoutingModule } from './onboarding-routing.module';
import { OnboardingComponent } from './onboarding.component';
import { NavbarComponent } from './hire/navbar/navbar.component';
import { CandidateComponent } from './hire/candidate/candidate.component';
import { JobComponent } from './hire/job/job.component';
import { FundingComponent } from './hire/funding/funding.component';
import { AppointmentComponent } from './hire/appointment/appointment.component';
import { AdministrativeComponent } from './hire/administrative/administrative.component';
import { FieldErrorDisplayComponent } from './field-error-display/field-error-display.component';
import { ApplicantComponent } from './applicant/applicant.component';
import { NavbarApplicantComponent } from './applicant/navbar-applicant/navbar-applicant.component';
import { IdentificationComponent } from './applicant/identification/identification.component';
import { AddressesComponent } from './applicant/addresses/addresses.component';
import { AppointmentAgreementComponent } from './applicant/appointment-agreement/appointment-agreement.component';

import { DirectDepositComponent } from './applicant/direct-deposit/direct-deposit.component';
import { GenderEthnicityComponent } from './applicant/gender-ethnicity/gender-ethnicity.component';
import { DisabilityStatusComponent } from './applicant/disability-status/disability-status.component';
import { VeteranStatusComponent } from './applicant/veteran-status/veteran-status.component';
import { HireComponent } from './hire/hire.component';

import { MyMaterialModule } from '../material.module';

@NgModule({
  imports: [
    CommonModule,
    NgbModule,
    FormsModule,
    AngularFontAwesomeModule,
    OnboardingRoutingModule,
    ReactiveFormsModule,
    MyMaterialModule
  ],
  declarations: [OnboardingComponent, NavbarComponent, CandidateComponent, JobComponent,FundingComponent, AppointmentComponent, AdministrativeComponent, FieldErrorDisplayComponent, ApplicantComponent, NavbarApplicantComponent, IdentificationComponent, AddressesComponent, AppointmentAgreementComponent, DirectDepositComponent, GenderEthnicityComponent, DisabilityStatusComponent, VeteranStatusComponent, HireComponent],
  //exports: [ OnboardingRoutingModule, OnboardingComponent, NavbarComponent, CandidateComponent, JobComponent,FundingComponent, AppointmentComponent, AdministrativeComponent  ]
 // declarations: [OnboardingComponent, NavbarComponent, CandidateComponent ],
  exports: [ OnboardingRoutingModule ]
})
export class OnboardingModule { }
