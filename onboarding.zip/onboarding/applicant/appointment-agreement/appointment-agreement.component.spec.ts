import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AppointmentAgreementComponent } from './appointment-agreement.component';

describe('AppointmentAgreementComponent', () => {
  let component: AppointmentAgreementComponent;
  let fixture: ComponentFixture<AppointmentAgreementComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AppointmentAgreementComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AppointmentAgreementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
