import { Component, OnInit, EventEmitter, Output  } from '@angular/core';
//import { CustomValidationService } from '../../../custom-validation.service';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormControl
} from '@angular/forms';

@Component({
  selector: 'app-identification',
  templateUrl: './identification.component.html',
  styleUrls: ['./identification.component.css']
})
export class IdentificationComponent implements OnInit {
  @Output() tabindex: EventEmitter<any> = new EventEmitter<any>();
  usCitizen: boolean = true; 
  val_immigration_status: any;
  exchange_visitor: any;
  primary_activity: any;
  birthday;
  date_entered_us;
  form: FormGroup;
  ssn: number;
  constructor(private formBuilder: FormBuilder) { }

  ngOnInit() {
    this.form = this.formBuilder.group({
      first_name: new FormControl('', [
        Validators.pattern("^[a-zA-Z]*$"),
        Validators.required
    ]),
      middle_name: '',
      last_name: new FormControl('', [
        Validators.pattern("^[a-zA-Z]*$"),
        Validators.required
    ]),
      birthday: [null, Validators.required],
      email: [null, Validators.required],
      email_validate: [null, Validators.required],
      phone: new FormControl('', [
        Validators.pattern("^[0-9]*$"),
        Validators.required
    ]),
     ssn: new FormControl('', [
      Validators.required,
      Validators.pattern("^[0-9]*$"),
      Validators.minLength(9)
      
  ]),
      us_citizen_status:'',
      primary_visit_activity: '',
      country_of_citizenship: '',
      foreign_residence_address: '',
      passport_number: '',
      passport_issuing_country: '',
      visa_number: '',
      date_entered_us: '',
      immigration_status: '',
      other_immigration_status: '',
      j1_immigration_subtype: ''
    });
  }
  public goToNext(tab: any): void {
    if (this.form.valid) {
    this.tabindex.emit(tab);
    }
    else {   
      this.validateAllFormFields(this.form); 
    }
   }
   checkCitizen(e) {
      if(e.target.value == "no") {
        this.usCitizen = false;
      }else{
        this.usCitizen = true;
      }
   }
   showAdditionalInfo(e) {
    this.val_immigration_status = e.target.value;
   }
   showAdditionalInfoExch(e) {
   this.exchange_visitor = e.target.value;
  }
  primaryActivityVisit(e) {
    this.primary_activity = e.target.value;
  }

  // Validation code
  isFieldValid(field: string) {
    console.log(!this.form.get(field).valid && this.form.get(field).touched);
   return !this.form.get(field).valid && this.form.get(field).touched;
 }
 
 displayFieldCss(field: string) {
   return {
     'has-danger': this.isFieldValid(field)
    //  'has-success': this.isFieldValid(field)
   };
 }
 validateAllFormFields(formGroup: FormGroup) {    
   Object.keys(formGroup.controls).forEach(field => {  
     const control = formGroup.get(field);  
     if (control instanceof FormControl) { 
       control.markAsTouched({ onlySelf: true });
       return false;
     } else if (control instanceof FormGroup) { 
       this.validateAllFormFields(control);
     }
   });
 }
}
