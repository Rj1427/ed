import { Component, OnInit, EventEmitter, Output, Input } from '@angular/core';
import { Router } from '@angular/router';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormControl
} from '@angular/forms';
import { MatDatepickerInputEvent } from '@angular/material';

@Component({
  selector: 'app-appointment',
  templateUrl: './appointment.component.new.html',
  styleUrls: ['./appointment.component.scss']
})
export class AppointmentComponent implements OnInit {
  @Output() tabindex: EventEmitter<any> = new EventEmitter<any>();
  @Input() step;
  form: FormGroup;
  start_date: any = '';
  end_date: any = '';
  isEndDateDisable: boolean = true;
  displayMonths;
  constructor(private router: Router, private formBuilder: FormBuilder) { }

  ngOnInit() {
    this.form = this.formBuilder.group({
      app_start_date: ['', Validators.required],
      app_end_date: ''
    });
  }
  addEvent(type: string, event: MatDatepickerInputEvent<Date>) {
    this.isEndDateDisable = false;
    this.start_date = event.value;
    const currentDate = new Date();
    const start: any = this.start_date.split('-');
    this.displayMonths = currentDate.setMonth(currentDate.getMonth() + 3);
  }
}
