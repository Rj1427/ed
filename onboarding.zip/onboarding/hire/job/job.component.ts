import { Router } from '@angular/router';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormControl
} from '@angular/forms';
import { Component, OnInit, EventEmitter, Output, Input } from '@angular/core';
import { FieldErrorDisplayComponent } from '../../field-error-display/field-error-display.component';
import { HireComponent } from '../hire.component'
import { HireService } from '../hire.service';

@Component({
  providers: [HireComponent],
  selector: 'app-job',
  templateUrl: './job.component.new.html',
  styleUrls: ['./job.component.scss']
})
export class JobComponent implements OnInit {
  tabToDisplay: number = 1;
  @Output() tabindex: EventEmitter<any> = new EventEmitter<any>();
  @Input() step;
  candidate: any;
  form: FormGroup;
  graduate_position_val: string;
  display_graduate_sec: boolean = false;

  hiring_department = [
    { key: '1010000156', name: '1010000156 - Office of the President' },
    { key: '1010000184', name: '1010000184 -  Office of the President-GIE' },
    { key: '1011000156', name: '1010000156 -  Admin Supp Serv-Stu Serv' },
    { key: '1017000156', name: '1017000156 - Boards - Institutional Support' },
    { key: '1018000144', name: '1018000144 - Commissions' },
    {
      key: '1013000156',
      name: '1013000156 - Office of Communication &amp; Mktg'
    }
  ];
  employment_Types = [
    { key: 'student', name: 'Student' },
    { key: 'federal', name: 'Federal Work Study' },
    { key: 'graduate', name: 'Graduate Assistant' },
    { key: 'hourly', name: 'Hourly Temporary' },
    { key: 'monthly', name: 'Monthly Temporary' },
    { key: 'lecturer-11', name: 'L11 Lecturer' },
    { key: 'lecturer-12', name: 'L12 Lecturer' },
    { key: 'house-h12', name: 'House Staff' }
  ];

  payPeriods = [
    { key: 'Hourly', name: 'Hourly' },
    { key: 'Monthly', name: 'Monthly' }
  ];

  graduate_positions= [
    { key: 'GF', name: 'Graduate Fellow' },
    { key: 'GTA', name: 'Graduate Teaching Assistant' },
    { key: 'GRA', name: 'Graduate Research Assistant' },
    { key: 'GSA', name: 'Graduate Service Assistant' }
  ];
  constructor(private router: Router, private formBuilder: FormBuilder, private hireService: HireService) { }

  ngOnInit() {
    this.candidate = this.hireService.candidateDetails;
    this.form = this.formBuilder.group({
      employment_type: [this.candidate.employment_type, Validators.required],
      position_number: this.candidate.position_number,
      hiring_department: [this.candidate.hiring_department, Validators.required],
      graduate_position_type: this.candidate.graduate_position_type,
      pay_rate: [this.candidate.pay_rate, [Validators.required,Validators.min(0)]],
      //pay_rate:  null,
      pay_period: [this.candidate.pay_period, Validators.required],
      hours_per_week: [this.candidate.hours_per_week, Validators.required]
    });

  }
  showAdditionalInfo(event) {
    this.graduate_position_val = event.target.value;
    this.tabindex.emit(this.tabToDisplay);
  }
  employment(event) {
    if (event.value == 'graduate') {
      this.display_graduate_sec = true;
    } else {
      this.display_graduate_sec = false;
    }
  }
  private getHireDeptName(id) {
    let len = this.hiring_department.length;
    for (let i = 0; i < len; i++) {
      if (this.hiring_department[i].key == id) {
        return this.hiring_department[i].name;
      }
    }
  }
  radioValue(event){
    this.graduate_position_val = event.value;
  }
  prevStep(tab: any): void {
    this.step = tab;
    this.tabindex.emit({ tab: tab, isPrev: true });
  }
  nextStep(tab: any): void {
    if (this.form.valid) {
      let hireDepName = this.getHireDeptName(this.form.value.hiring_department);
      this.form.value.hireDepName = hireDepName;

      let sendToParent = { tab: tab, formVal: this.form.value };
      this.tabindex.emit(sendToParent);
    } else {
      this.validateAllFormFields(this.form);
    }
  }
  isFieldValid(field: string) {
    //console.log(!this.form.get(field).valid && this.form.get(field).touched);
    return !this.form.get(field).valid && this.form.get(field).touched;
  }

  displayFieldCss(field: string) {
    return {
      'has-error': this.isFieldValid(field),
      'has-feedback': this.isFieldValid(field)
    };
  }
  validateAllFormFields(formGroup: FormGroup) {
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field);
      if (control instanceof FormControl) {
        control.markAsTouched({ onlySelf: true });
        return false;
      } else if (control instanceof FormGroup) {
        this.validateAllFormFields(control);
      }
    });
  }
}
