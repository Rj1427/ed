import { Router } from '@angular/router';
import { Component, OnInit, EventEmitter, Output, Input } from '@angular/core';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormControl
} from '@angular/forms';
@Component({
  selector: 'app-administrative',
  templateUrl: './administrative.component.new.html',
  styleUrls: ['./administrative.component.scss']
})
export class AdministrativeComponent implements OnInit {
  @Output() tabindex: EventEmitter<any> = new EventEmitter<any>();
  @Input() step;
  candidate: any;
  form: FormGroup;
  constructor(
    private router: Router,
    private formBuilder: FormBuilder
  ) { }

  ngOnInit() {
    this.form = this.formBuilder.group({
      supervisor_name: ['', Validators.required],
      supervisor_email: ['', [Validators.required, Validators.email]],
      comment: ''
    });
  }
  prevStep(tab: any): void {
    this.step = tab;
    this.tabindex.emit({ tab: tab, isPrev: true });
  }
  finishStep(tab) {
    if (this.form.valid) {
      //this.router.navigate(['/home', {success: true}]);
      let sendToParent = { tab: tab, formVal: this.form.value };
      this.tabindex.emit(sendToParent);
    } else {
      this.validateAllFormFields(this.form);
    }
  }
  isFieldValid(field: string) {
    return !this.form.get(field).valid && this.form.get(field).touched;
  }

  displayFieldCss(field: string) {
    return {
      'has-error': this.isFieldValid(field),
      'has-feedback': this.isFieldValid(field)
    };
  }

  validateAllFormFields(formGroup: FormGroup) {
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field);
      if (control instanceof FormControl) {
        control.markAsTouched({ onlySelf: true });
        return false;
      } else if (control instanceof FormGroup) {
        this.validateAllFormFields(control);
      }
    });
  }
}
